<style>
.sorting_disabled {
    display:block !important;
}
.display-block{
     display:table-cell !important;
}
.btn-action{
     padding: 0px 0px !important;
}
.view-edit{
  padding: 10px 15px !important;
  margin: 0.3125rem 1px !important;
}

 .borderless tr, .borderless td, .borderless th {
    border: none !important;
   }

  .list-group{
          max-height: 450px;
          margin-bottom: 10px;
          overflow:scroll;
          -webkit-overflow-scrolling: touch;
           max-width: 300px;
      }

.card {
   
    min-height: 600px;
}

#map {
    margin-top: 15px !important;
}

.buttons {
  width: 200px;
}

.action_btn {
  display: inline-block;
  width: calc(50% - 4px);
  margin: 0 auto;
}

</style>


@extends('layouts.app', ['activePage' => 'journey-plan', 'menuParent' => 'Journey-Plan', 'titlePage' => __('Outlet Details')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header card-header-rose card-header-icon">
                <div class="card-icon">
                  <i class="material-icons">details</i>
                </div>
                <h4 class="card-title">{{ __('Outlet Details') }}</h4>
              </div>

              <div class="details" style="margin-left: 20px;margin-top: 20px;">

                <span id="store_code" style="font-weight: 400;font-size: 30px;"></span> <span id="outlet_name" style="font-weight: 400;font-size: 30px;"></span><br>

                <span id="address" style="font-size: 20px;margin-bottom: 10px;" ></span><br><br>

                <table>
                    
                    <tr><td>Contact No</td><td>:</td><td id="contact_no"></td></tr>
                    <tr><td>program Name</td><td>:</td><td id="program_name">Tang6985</td></tr>
                    <tr><td>Distance</td><td>:</td><td id="distance">-</td></tr>
                    <tr><td>Last Visit</td><td>:</td><td id="last_visit"></td></tr>


                </table>
              </div>


              <div class="card-body">
                <div class="row">
                     <!--  <button id="check_in" class="btn btn-success  ml-auto" value="" onclick="check_in(this.value)">Check In</button> -->

                            <button name="submit" id="check_out" class="btn btn-danger"  value="" onclick="check_out(this.value)">Check Out</button>
                            <button name="submit" id="check_in" class="btn btn-success ml-auto" value="" onclick="check_in(this.value)">Check In</button>
                    
                      <div id="map" style="float:left;width:100%;"></div>
                     
                  </div>
            
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>

@endsection

<script src=" https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js
"></script>


@push('js')
  <script>


 $(function () {
                  
        $(".datepicker").datetimepicker({
            format: 'DD-MM-YYYY',
            useCurrent: false
        });

        //init();
        //get_plan();

  });
  
    $(document).ready(function() {
  
    // initialise Datetimepicker and Sliders
  
      md.initFormExtendedDatetimepickers();
         
      if ($('.slider').length != 0) {
      
        md.initSliders();
      } 

      locations();
      
    }); 

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function() {
      $('#datatables').fadeIn(1100);
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search",
        },
        "columnDefs": [
          { "orderable": false, "targets": 5 },
        ],
      });
    });


    function locations(){

        var csrf = $('meta[name="csrf-token"]').attr('content');

        var url = $(location).attr('href');

        var id = url.substr(url.lastIndexOf('/') + 1);

        //alert(id);

        $.ajax({
          url: '/outlet_detail',
          type: 'GET',
          data: {'_token': csrf, 'id':id},
          dataType: 'json',
          success: function( data ) { 
               //alert(data[1].last_visit)
                $("#store_code").html("["+data[0]['store_code']+"]"); contact_no
                $("#outlet_name").html(data[0]['store_name']);
                $("#address").html(data[0]['address']);  
                $("#contact_no").html(data[0]['contact_number']);
                $("#last_visit").html(data[1].last_visit);
                $("#check_in").val(id);
                $("#check_out").val(id);

                google_maps(data);
            }    
        })

    }

  

    //  google_maps(json);
   
   
     function google_maps(data)
     {

      //  alert(data[0]['outlet']['outlet_lat']);  

         const myLatLng = { lat: parseFloat(data[0]['outlet']['outlet_lat']), lng: parseFloat(data[0]['outlet']['outlet_long']) };
          const map = new google.maps.Map(document.getElementById("map"), {
            zoom: 13,
            center: myLatLng,
          });
          new google.maps.Marker({
            position: myLatLng,
            map,
            title: data[0]['outlet']['outlet_name'],
          });

        }

function check_in(id)
{
    //alert(id);

    //return false;

    var csrf = $('meta[name="csrf-token"]').attr('content');

    $.ajax({
          url: '/outlet_check_in',
          type: 'POST',
          data: {id : id, _token: csrf},
          dataType: 'json',

          success: function( data ) {
             alert("Check In Successfully..");

             
          }       
      })

// if (navigator.geolocation) {

//     navigator.geolocation.getCurrentPosition(function(position, html5Error){
//       //alert(id);
//         geo_loc = processGeolocationResult(position);
//         currLatLong = geo_loc.split(",");
//        // initializeCurrent(currLatLong[0], currLatLong[1]);

//         currgeocoder = new google.maps.Geocoder();
//          console.log(latcurr + "-- ######## --" + longcurr);

//          if (currLatLong[0] != '' && currLatLong[1] != '') {
//              var myLatlng = new google.maps.LatLng(currLatLong[0], currLatLong[1]);
//              console.log(myLatlng);
//             // return getCurrentAddress(myLatlng);

//               currgeocoder.geocode({
//               'location': myLatlng

//                 }, function(results, status) {

//                     if (status == google.maps.GeocoderStatus.OK) {
//                         //$("#address").html(results[0].formatted_address);


//                           $.ajax({
//                               url: '/outlet_check_in',
//                               type: 'POST',
//                               data: {id : id, _token: csrf},
//                               dataType: 'json',

//                               success: function( data ) {
//                                  alert("Check In Successfully..");

                                 
//                               }       
//                           })


//                     } else {
//                         alert('Geocode was not successful for the following reason: ' + status);
//                     }

//                 });


//          }

//     });

//   } 

}

function check_out(id)
{
    //alert(id);

    var csrf = $('meta[name="csrf-token"]').attr('content');

    $.ajax({
          url: '/outlet_check_out',
          type: 'POST',
          data: {id : id, _token: csrf},
          dataType: 'json',

          success: function( data ) {
             alert("Check Out Successfully..");


          }       
      })

// if (navigator.geolocation) {

//     navigator.geolocation.getCurrentPosition(function(position, html5Error){

//         geo_loc = processGeolocationResult(position);
//         currLatLong = geo_loc.split(",");
//        // initializeCurrent(currLatLong[0], currLatLong[1]);

//         currgeocoder = new google.maps.Geocoder();
//         // console.log(latcurr + "-- ######## --" + longcurr);

//          if (currLatLong[0] != '' && currLatLong[1] != '') {
//              var myLatlng = new google.maps.LatLng(currLatLong[0], currLatLong[1]);
//              console.log(myLatlng);
//             // return getCurrentAddress(myLatlng);

//               currgeocoder.geocode({
//               'location': myLatlng

//                 }, function(results, status) {

//                     if (status == google.maps.GeocoderStatus.OK) {
//                         //$("#address").html(results[0].formatted_address);


//                           $.ajax({
//                               url: '/outlet_check_out',
//                               type: 'POST',
//                               data: {id : id, lat : position.coords.latitude, lng : position.coords.longitude, _token: csrf, address : results[0].formatted_address},
//                               dataType: 'json',

//                               success: function( data ) {
//                                  alert("Check Out Successfully..");


//                               }       
//                           })


//                     } else {
//                         alert('Geocode was not successful for the following reason: ' + status);
//                     }

//                 });


//          }

//     });

//   } 

}

 function processGeolocationResult(position) {
     html5Lat = position.coords.latitude; //Get latitude
     html5Lon = position.coords.longitude; //Get longitude
     //console.log(html5Lat);
     //console.log(html5Lon);
     html5TimeStamp = position.timestamp; //Get timestamp
     html5Accuracy = position.coords.accuracy; //Get accuracy in meters
     return (html5Lat).toFixed(8) + ", " + (html5Lon).toFixed(8);
   }

  </script>

@endpush
