<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Outlet extends Model
{
    use HasFactory;
    use Notifiable;
    
    protected $table = 'outlet';

    public $timestamps = true;
     
    protected $fillable = [
         'outlet_id','outlet_name','outlet_lat', 'outlet_longi' ,'outlet_area','outlet_city','outlet_state','outlet_country','is_active'];
    
    public function timesheet()
    {
        return $this->belongsTo(merchant_timesheet::class,"outlet_id");
    }
    
    public function store()
    {
        return $this->hasMany(Store_details::class,"id","outlet_name");
    }
    
}
    
    
